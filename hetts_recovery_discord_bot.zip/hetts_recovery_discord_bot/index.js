const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require("discord.js");
const fs = require("node:fs");
const path = require("node:path");

const TOKEN = process.env.DISCORD_BOT_TOKEN;
const CLIENT_ID = process.env.DISCORD_CLIENT_ID;
const OWNER_ID = process.env.OWNER_DISCORD_ID;
if (!TOKEN || !CLIENT_ID || !OWNER_ID) throw new Error("Set DISCORD_BOT_TOKEN, DISCORD_CLIENT_ID, OWNER_DISCORD_ID in hosting secrets.");

const dir = path.join(__dirname, "data");
const file = path.join(dir, "cases.json");
fs.mkdirSync(dir, { recursive: true });
if (!fs.existsSync(file)) fs.writeFileSync(file, "[]");
const read = () => JSON.parse(fs.readFileSync(file, "utf8"));
const write = data => fs.writeFileSync(file, JSON.stringify(data, null, 2));
const clean = (v, n=500) => String(v || "").trim().slice(0, n);
const ownerOnly = i => i.user.id === OWNER_ID;

const commands = [
 new SlashCommandBuilder().setName("case-create").setDescription("Create a support case")
  .addStringOption(o=>o.setName("username").setDescription("Instagram username only").setRequired(true))
  .addStringOption(o=>o.setName("reason").setDescription("What happened?").setRequired(true))
  .addStringOption(o=>o.setName("notes").setDescription("Relevant context; never add passwords or OTPs").setRequired(false)),
 new SlashCommandBuilder().setName("case-list").setDescription("List tracked cases"),
 new SlashCommandBuilder().setName("case-status").setDescription("View a case")
  .addStringOption(o=>o.setName("id").setDescription("Case ID").setRequired(true)),
 new SlashCommandBuilder().setName("case-update").setDescription("Update a case")
  .addStringOption(o=>o.setName("id").setDescription("Case ID").setRequired(true))
  .addStringOption(o=>o.setName("status").setDescription("Current status").setRequired(true)
   .addChoices({name:"New",value:"New"},{name:"Evidence needed",value:"Evidence needed"},{name:"Appeal prepared",value:"Appeal prepared"},{name:"Submitted to official support",value:"Submitted to official support"},{name:"Under review (confirmed)",value:"Under review (confirmed)"},{name:"Resolved",value:"Resolved"},{name:"Closed",value:"Closed"}))
  .addStringOption(o=>o.setName("notes").setDescription("Update notes").setRequired(false)),
 new SlashCommandBuilder().setName("appeal-draft").setDescription("Draft a truthful appeal for a case")
  .addStringOption(o=>o.setName("id").setDescription("Case ID").setRequired(true))
].map(c=>c.toJSON());

const client = new Client({intents:[GatewayIntentBits.Guilds]});
client.once("ready",()=>console.log(`HETT'S RECOVERY online as ${client.user.tag}`));
client.on("interactionCreate", async i=>{
 if (!i.isChatInputCommand()) return;
 if (!ownerOnly(i)) return i.reply({content:"Private bot: only its owner can use it.",ephemeral:true});
 const cases=read(), cmd=i.commandName;
 if (cmd==="case-create") {
  const username=clean(i.options.getString("username"),100).replace(/^@/,"");
  const reason=clean(i.options.getString("reason"),500), notes=clean(i.options.getString("notes"),1200);
  if (!/^[A-Za-z0-9._]+$/.test(username)) return i.reply({content:"Enter a valid Instagram username.",ephemeral:true});
  const id=String(Math.max(1000,...cases.map(c=>Number(c.id)||0))+1);
  const c={id,username,reason,notes,status:"New",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
  cases.push(c); write(cases);
  return i.reply({content:`**Case #${id} created** for @${username}. Status: New\\nNever enter passwords, OTPs, session cookies, or identity documents.`,ephemeral:true});
 }
 if (cmd==="case-list") {
  const rows=cases.slice(-15).reverse().map(c=>`**#${c.id}** @${c.username} — ${c.status}`);
  return i.reply({content:rows.length?rows.join("\\n"):"No cases yet. Use `/case-create`.",ephemeral:true});
 }
 const id=clean(i.options.getString("id"),20), c=cases.find(x=>x.id===id);
 if (!c) return i.reply({content:`Case #${id} not found.`,ephemeral:true});
 if (cmd==="case-status") return i.reply({content:`**Case #${c.id} — @${c.username}**\\nReason: ${c.reason}\\nStatus: ${c.status}\\nNotes: ${c.notes||"None"}\\nUpdated: ${c.updatedAt}`,ephemeral:true});
 if (cmd==="case-update") {
  c.status=i.options.getString("status");
  const notes=i.options.getString("notes"); if(notes) c.notes=clean(notes,1200);
  c.updatedAt=new Date().toISOString(); write(cases);
  return i.reply({content:`Case #${id} updated: **${c.status}**`,ephemeral:true});
 }
 if (cmd==="appeal-draft") {
  const draft=`Hello Instagram Support,\\n\\nI am requesting a review of @${c.username}. The issue I experienced is: ${c.reason}.${c.notes?` Relevant context: ${c.notes}.`:""}\\n\\nI believe this action may have been taken in error. Please review the account and let me know if any further information is required.\\n\\nThank you.`;
  return i.reply({content:`**Please check this draft for accuracy before sending:**\\n\\n${draft}`,ephemeral:true});
 }
});
(async()=>{const rest=new REST({version:"10"}).setToken(TOKEN); await rest.put(Routes.applicationCommands(CLIENT_ID),{body:commands}); await client.login(TOKEN);})().catch(e=>{console.error(e);process.exit(1);});
