# HETT'S RECOVERY — private Discord case bot

Commands: `/case-create`, `/case-list`, `/case-status`, `/case-update`, `/appeal-draft`.

This starter organizes cases and drafts truthful appeals for you to review. It does NOT connect to Meta AI, summon human Meta agents, inspect Instagram accounts, submit appeals to Meta, or guarantee recovery. Direct Meta automation requires an officially supported integration and permission.

Never enter passwords, OTPs, backup codes, session cookies, or identity documents into Discord or this bot.

Deploy on a Node.js host that supports a continuously running process and persistent storage. Install with `npm install`, set the hosting secrets `DISCORD_BOT_TOKEN`, `DISCORD_CLIENT_ID`, and `OWNER_DISCORD_ID`, then use `npm start`. The bot saves cases to `data/cases.json`; use persistent storage or data may be lost on redeploy.
